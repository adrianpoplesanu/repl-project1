package com.adrianpoplesanu.AdWebApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdWebApplication.class, args);
	}

}
