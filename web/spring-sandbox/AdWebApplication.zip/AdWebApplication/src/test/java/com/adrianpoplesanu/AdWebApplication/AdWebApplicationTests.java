package com.adrianpoplesanu.AdWebApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
