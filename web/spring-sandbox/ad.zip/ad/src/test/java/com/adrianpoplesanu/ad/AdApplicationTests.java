package com.adrianpoplesanu.ad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdApplicationTests {

	@Test
	void contextLoads() {
	}

}
